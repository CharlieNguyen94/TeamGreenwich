<?php
include_once 'header.php';
// Include config file
require_once 'config.php';
 
// Define variables and initialize with empty values
$username = $password = "";
$username_err = $password_err = "";
 
// Processing form data when form is submitted
if($_SERVER["REQUEST_METHOD"] == "POST"){
 
    // Check if username is empty
    if(empty(trim($_POST["username"]))){
        $username_err = 'Please enter username.';
    } else{
        $username = trim($_POST["username"]);
    }
    
    // Check if password is empty
    if(empty(trim($_POST['password']))){
        $password_err = 'Please enter your password.';
    } else{
        $password = trim($_POST['password']);
    }
    
    // Validate credentials
    if(empty($username_err) && empty($password_err)){
        // Prepare a select statement
        $sql = "SELECT username, password FROM users WHERE username = ?";
        
        if($stmt = $mysqli->prepare($sql)){
            // Bind variables to the prepared statement as parameters
            $stmt->bind_param("s", $param_username);
            
            // Set parameters
            $param_username = $username;
            
            // Attempt to execute the prepared statement
            if($stmt->execute()){
                // Store result
                $stmt->store_result();
                
                // Check if username exists, if yes then verify password
                if($stmt->num_rows == 1){                    
                    // Bind result variables
                    $stmt->bind_result($username, $hashed_password);
                    if($stmt->fetch()){
                        if(password_verify($password, $hashed_password)){
                            /* Password is correct, so start a new session and
                            save the username to the session */
                            session_start();
                            $_SESSION['username'] = $username;      
                            header("location: welcome.php");
                        } else{
                            // Display an error message if password is not valid
                            $password_err = 'The password you entered was not valid.';
                        }
                    }
                } else{
                    // Display an error message if username doesn't exist
                    $username_err = 'No account found with that username.';
                }
            } else{
                echo "Oops! Something went wrong. Please try again later.";
            }
        }
        
        // Close statement
        $stmt->close();
    }
    
    // Close connection
    $mysqli->close();
}
?>

<div class="container">

    <div class="col-md-12 col-lg-12 col-xs-6 col-sm-6">

        <div class="panel panel-default">
            <div class="panel-heading">

            </div>
            <div class="panel-body">

                <div class="col-sm-12 col-lg-6 col-xs-12 col-md-6">
                    <img src="assets/logo.png">
                </div>
                <div class="col-sm-12 col-lg-6 col-xs-12 col-md-6">
                    <form class="form-horizontal form-bordered">
                        <div class="form-group">
                            <label class="col-md-4 control-label"> UserName<span class="codex-required">
                                *
                            </span></label>
                            <div class="col-md-6">
                                <input type="text" class="form-control" name="username" required>
                            </div>
                        </div>


                        <div class="form-group">
                            <label class="col-md-4 control-label">Password <span class="codex-required">
                                *
                            </span>
                            </label>
                            <div class="col-md-6">
                                <input type="password" class="form-control" name="password" required>
                            </div>
                        </div>

                        <div class="modal-footer">
                            <button type="button" class="btn btn-sm btn-success">login</button>
                            <a href="register.php">Not a member register</a>
                        </div>
                    </form>
                </div>

                <div class="col-lg-12 col-sm-12 col-xs-12 col-md-12" >
                    <strong>
                       
                    </strong>
                </div>


            </div>
        </div>

    </div>
</div>

<?php
include_once 'footer.php';
?>