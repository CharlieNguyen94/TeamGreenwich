
<nav class="panel-footer navbar-fixed-bottom">
    <div style="text-align: center">
        &copy; <?= date('Y') ?> All Rights Reserved
    </div>
</nav>
