<?php

define('DB_SERVER', 'mysql.cms.gre.ac.uk');
define('DB_USERNAME', 'mm0823o');
define('DB_PASSWORD', 'mm0823o');
define('DB_NAME', 'mdb_mm0823o');

$link = mysqli_connect(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);

if($link === false){
    die("ERROR: Unable to connect.".mysqli_connect_error());    
}

?>