<?php  include('forumfunction.php'); ?>


<?php 
	if (isset($_GET['edit'])) {
		$id = $_GET['edit'];
		$update = true;
		$record = mysqli_query($db, "SELECT * FROM forum WHERE id=$id");

		if (count($record) == 1 ) {
			$n = mysqli_fetch_array($record);
			$name = $n['name'];
			$idea = $n['idea'];
            $comment = $n['comment'];
		}
	}
?>


<!DOCTYPE html>
<html>
<head>
	<title>ForumL</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<?php if (isset($_SESSION['message'])): ?>
	<div class="msg">
		<?php 
			echo $_SESSION['message']; 
			unset($_SESSION['message']);
		?>
	</div>
<?php endif ?>
    
    
    <?php $results = mysqli_query($db, "SELECT * FROM forum"); ?>

<table>
	<thead>
		<tr>
			<th>Name</th>
			<th>Idea</th>
            <th>Comment</th>
			<th colspan="2">Action</th>
		</tr>
	</thead>
	
	<?php while ($row = mysqli_fetch_array($results)) { ?>
		<tr>
			<td><?php echo $row['name']; ?></td>
			<td><?php echo $row['idea']; ?></td>
            <td><?php echo $row['comment']; ?></td>
			<td>
				<a href="forum.php?edit=<?php echo $row['id']; ?>" class="edit_btn" >Edit</a>
			</td>
			<td>
				<a href="forumfunction.php?del=<?php echo $row['id']; ?>" class="del_btn">Delete</a>
			</td>
		</tr>
	<?php } ?>
</table>

    
    
    
	<form method="post" action="forumfunction.php" >
        




		<div class="input-group">
            <input type="hidden" name="id" value="<?php echo $id; ?>">
			<label>Name</label>
			<input type="text" name="name" value="<?php echo $name; ?>">
		</div>
		<div class="input-group">
			<label>Idea</label>
			<input type="text" name="idea" value="<?php echo $idea; ?>">
        </div>
        <div class="input-group">
			<label>Comment</label>
			<input type="text" name="comment" value="<?php echo $comment; ?>">
		</div>
		<div class="input-group">
			<?php if ($update == true): ?>
	<button class="btn" type="submit" name="update" style="background: #556B2F;" >update</button>
<?php else: ?>
	<button class="btn" type="submit" name="save" >Save</button>
<?php endif ?>
            <a href="index.php" >Home</a>
		</div>
	</form>
</body>
</html>