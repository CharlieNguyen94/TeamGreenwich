<?php 
	session_start();
	$db = mysqli_connect('localhost', 'root', '', 'tg');

	// initialize variables
	$name = "";
	$idea = "";
    $comment = "";
	$id = 0;
	$update = false;

	if (isset($_POST['save'])) {
		$name = $_POST['name'];
		$idea = $_POST['idea'];
        $comment = $_POST['comment'];

		mysqli_query($db, "INSERT INTO forum (name, idea, comment) VALUES ('$name', '$idea', '$comment')"); 
		$_SESSION['message'] = "Idea saved"; 
		header('location: forum.php');
	}

if (isset($_POST['update'])) {
	$id = $_POST['id'];
	$name = $_POST['name'];
	$idea = $_POST['idea'];
    $comment = $_POST['comment'];

	mysqli_query($db, "UPDATE forum SET name='$name', idea='$idea',comment='$comment'  WHERE id=$id");
	$_SESSION['message'] = "Idea updated!"; 
	header('location: forum.php');
}

if (isset($_GET['del'])) {
	$id = $_GET['del'];
	mysqli_query($db, "DELETE FROM forum WHERE id=$id");
	$_SESSION['message'] = "Idea deleted!"; 
	header('location: forum.php');
}